<?php 
session_start();
require_once "";
$flag = true;
if (!$_POST["name"]) {
    $_SESSION['name'] = "Plase Enter The Desicnation";
    $flag = false;
} else {
    $_SESSION['check_name'] = $_POST["name"];
}
if (!$_POST["duration"]) {
    $_SESSION['duration'] = "Plase Enter The duration";
    $flag = false;
} else {
    $_SESSION['check_duration'] = $_POST["duration"];
}
if (!$_POST["description"]) {
    $_SESSION['description'] = "Plase Enter The Description";
    $flag = false;
} else {
    $_SESSION['check_description'] = $_POST["description"];
}

if ($flag) {
    $name = $_POST['name'];
    $duration = $_POST['duration'];
    $description = $_POST['description'];
    $name = $_POST['created_at'];
    date_default_timezone_set('Asia/Dhaka');
    $date_time = date('Y-m-d H:i:s');
    $insert_query = "INSERT INTO experiences (name, duration, description, created_at) VALUES ('$name','$duration','$description','$date_time')";
    $register_query = mysqli_query($db_connact, $insert_query);
}else{
    header("location: experience.php");
}




// date_default_timezone_set('Asia/Dhaka');
// $date_time = date('Y-m-d H:i:s');
?>