$('.icon').click(function(){
    $('#icon_id').val($(this).attr("id"));
});