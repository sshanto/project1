<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Abstack - Responsive Bootstrap 4 Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- App css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<body class="authentication-bg bg-gradient">

    <div class="account-pages pt-5 mt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <a href="index.html">
                                    <span><img src="images/logo-dark.png" alt="" height="18"></span>
                                </a>
                                <h5 class="text-uppercase text-center font-bold mt-4">Register</h5>
                            </div>
                            <?php if (isset($_SESSION['register_check'])) : ?>
                                <div class="text-danger"><?= $_SESSION['register_check'] ?></div>
                            <?php endif; ?>
                            <form action="register_post.php" method="POST">

                                <div class="form-group">
                                    <label for="fullname">Name</label>
                                    <input name="name" class="form-control <?= isset($_SESSION['name']) ? 'is-invalid' : ''  ?> " type="text" id="fullname" placeholder="Enter your name" value="<?= (isset($_SESSION['check_name'])) ? $_SESSION['check_name'] : ''  ?>">
                                    <?php if (isset($_SESSION['name'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['name'] ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="emailaddress">Email address</label>
                                    <input name="email" class="form-control <?= isset($_SESSION['email']) ? 'is-invalid' : ''  ?>" type="email" id="emailaddress" placeholder="Enter your email" value="<?= (isset($_SESSION['check_email'])) ? $_SESSION['check_email'] : ''  ?>">
                                    <?php if (isset($_SESSION['email'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['email'] ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password">Password</label>
                                    <input name="password" class="form-control <?= isset($_SESSION['password']) ? 'is-invalid' : ''  ?>" type="password" id="password" placeholder="Enter your password">
                                    <?php if (isset($_SESSION['password'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['password'] ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <label for="password">confirm Password</label>
                                    <input name="confram_password" class="form-control <?= isset($_SESSION['confram_password']) ? 'is-invalid' : ''  ?>" type="password" id="password" placeholder="Enter your confram password">
                                    <?php if (isset($_SESSION['confram_password'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['confram_password'] ?></small>
                                    <?php endif; ?>
                                    <?php if (isset($_SESSION['password_match'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['password_match'] ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group">
                                    <div class="mt-3">
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="customRadio1" name="gender" class="custom-control-input" value="male" <?= (isset($_SESSION['check_gender']) && $_SESSION['check_gender'] == 'male') ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="customRadio1">Male</label>
                                        </div>
                                        <div class="custom-control custom-radio">
                                            <input type="radio" id="customRadio2" name="gender" class="custom-control-input" value="female" <?= (isset($_SESSION['check_gender']) && $_SESSION['check_gender'] == 'female') ? 'checked' : '' ?>>
                                            <label class="custom-control-label" for="customRadio2">Female</label>
                                        </div>
                                    </div>
                                    <?php if (isset($_SESSION['gender'])) : ?>
                                        <small class="text-danger"><?= $_SESSION['gender'] ?></small>
                                    <?php endif; ?>
                                </div>
                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-gradient btn-block waves-effect waves-light " id="toastr-three" type="submit"> Register </button>
                                </div>

                            </form>

                            <div class="row mt-4">
                                <div class="col-sm-12 text-center">
                                    <p class="text-muted mb-0">Already have an account? <a href="login.php" class="text-dark ml-1"><b>Sign In</b></a></p>
                                </div>
                            </div>

                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->



                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <!-- Vendor js -->
    <script src="js/vendor.min.js"></script>

    <!-- App js -->
    <script src="js/app.min.js"></script>

</body>

</html>

<?php
session_unset();
?>