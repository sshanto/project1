<?php
require_once "../db.php";
testone_delete_photo("uploadphotos", "id", $_GET['id'], "new_photo_name");
header("location: photo-uploads.php");

?>
