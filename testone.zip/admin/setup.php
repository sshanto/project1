<?php
require_once "inc/header.php";
require_once "../db.php";
?>

<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Abstack</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                <li class="breadcrumb-item active">Form Validation</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Form Validation</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-6">

                    <div class="card-box">
                        <h4 class="header-title">Experience</h4>
                        <p class="sub-header">
                            Create The Experience In Your From
                        </p>
                        <form class="parsley-examples" action="setup_edit.php" method="POST">
                            <div class="form-group">
                                <label for="userName">Author Name<span class="text-danger">*</span></label>
                                <input type="text" name="authorname" value="<?= testone_setup('genaral_setup', 'authorname') ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="emailAddress">Email<span class="text-danger">*</span></label>
                                <input type="email" name="email" parsley-trigger="change"
                                    value="<?= testone_setup('genaral_setup', 'email') ?>" class="form-control">
                            </div>
                            <div class="form-group">
                                <label for="emailAddress">Phone<span class="text-danger">*</span></label>
                                <input type="number" name="phone" parsley-trigger="change"
                                    class="form-control" value="<?= testone_setup('genaral_setup', 'phone') ?>">
                            </div>
                            <div class="form-group">
                                <label for="pass1">About Me<span class="text-danger">*</span></label>
                                <textarea name="about_me" class="form-control"><?= testone_setup('genaral_setup', 'about_me') ?></textarea>
                            </div>

                            <div class="form-group text-right mb-0">
                                <button class="btn btn-gradient waves-effect waves-light" type="submit">
                                    Update
                                </button>
                                <button type="reset" class="btn btn-light waves-effect ml-1">
                                    Cancel
                                </button>
                            </div>

                        </form>
                    </div> <!-- end card-box -->
                </div>
                <!-- end col -->

                <div class="col-lg-6">
                    <div class="card-box">
                        <h4 class="header-title">Table</h4>
                        <p class="sub-header">
                            Parsley is a javascript form validation library. It helps you provide your users with feedback on their form submission before sending it to your server.
                        </p>
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Duration</th>
                                    <th>description</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach (testone('experiences') as $experience) :
                                ?>
                                    <tr>
                                        <th><?= $experience['name']  ?></th>
                                        <th><?= $experience['duration']  ?></th>
                                        <th><?= $experience['description']  ?></th>
                                        <th>
                                            <a href="" class="btn btn-sm btn-info"><i class="dripicons-document-edit"></i></a>
                                        </th>
                                        <th>
                                            <a href="experience-delete.php?id=<?= $experience['id']  ?>" class="btn btn-sm btn-danger"><i class="dripicons-document-edit"></i></a>
                                        </th>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div> <!-- end col -->
            </div>
            <!-- end row -->


        </div> <!-- end container-fluid -->

    </div> <!-- end content -->


    <?php
    require_once "inc/footer.php";
    ?>