<?php
require_once "../db.php";
testone_delete("experiences", "id", $_GET['id']);
header("location: experience.php");
?>