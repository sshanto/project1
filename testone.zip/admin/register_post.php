<?php 
require_once "../db.php";
// print_r($_POST["name"]);
session_start();
$flag = true;

if (!$_POST["name"]) {
    $_SESSION['name'] = "Plase Enter Your Name";
    $flag = false;
}else{
    $_SESSION['check_name'] = $_POST["name"];
}
if (!$_POST["email"]) {
    $_SESSION['email'] = "Plase Enter Your Email";
    $flag = false;
} else {
    $_SESSION['check_email'] = $_POST["email"];
}
if (!$_POST["password"]) {
    $_SESSION['password'] = "Enter Your Password";
    $flag = false;
}
if (!$_POST["confram_password"]) {
    $_SESSION['confram_password'] = "Enter Your Confram Password";;
    $flag = false;
}else{
    if ($_POST["password"] != $_POST["confram_password"]) {
        $_SESSION['password_match'] = "Password Not Match";
        $flag = false;
    }
}

if (!isset($_POST["gender"])) {
    $_SESSION['gender'] = "Select Your Gender";
    $flag = false;
}else {
    $_SESSION['check_gender'] = $_POST["gender"];
}

if ($flag) {
    // print_r($_POST);
   $name = $_POST['name'];
   $email = $_POST['email'];
   $password = md5($_POST['password']);
   $gender = $_POST['gender'];
  echo $email_check = "SELECT COUNT(*) AS email_check FROM users WHERE email='$email'";
  if (mysqli_fetch_assoc(mysqli_query(connect_to_db(), $email_check))['email_check'] == 1) {
    $_SESSION['register_check'] = "The Email Address Is Already Token!";
    header("location: register.php");
  }else{
        date_default_timezone_set('Asia/Dhaka');
        $date_time = date('Y-m-d H:i:s');
        $insert_query = "INSERT INTO users (name, email, password, gender, created_at) VALUES ('$name','$email','$password','$gender','$date_time')";
        $register_query = mysqli_query(connect_to_db(), $insert_query);
        $_SESSION['email_value'] = $email;
        $_SESSION['success'] = "Register Done! Now You Can Login Your Site!";
        header('location: login.php');
  }
    
}else{
    header('location: register.php');
}
?>