<?php
require_once "../db.php";
$icon_name = $_POST['icon_name'];

$returen_v = testone_insert("icons", "icon_name", "'$icon_name'");
// print_r($returen_v);
if ($returen_v) {
    header("location: icon.php");
}
?>