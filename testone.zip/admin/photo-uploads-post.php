<?php 
require_once "../db.php";
// photo uploads start
$uploads_photo = $_FILES['new_photo_name'];
$after_explode = explode('.',$uploads_photo['name']);
$new_photo_name = rand().time().".".end($after_explode);
$uploads_temp_location = $uploads_photo['tmp_name'];
$new_location = '../images/uploadphotos/'. $new_photo_name;
move_uploaded_file($uploads_temp_location, $new_location);
// photo uploads end

$name = $_POST['name'];
$description = htmlspecialchars($_POST['description'], ENT_QUOTES);
date_default_timezone_set('Asia/Dhaka');
$date_time = date('Y-m-d H:i:s');


$returen_v = testone_insert("uploadphotos", "name,new_photo_name,description,created_at", "'$name','$new_photo_name','$description','$date_time'");
// print_r($returen_v);
if ($returen_v) {
    header("location: photo-uploads.php");
}
?>