<?php
require_once "inc/header.php";
require_once "../db.php";
?>

<!-- ============================================================== -->
<!-- Start Page Content here -->
<!-- ============================================================== -->

<div class="content-page">
    <div class="content">

        <!-- Start Content-->
        <div class="container-fluid">

            <!-- start page title -->
            <div class="row">
                <div class="col-12">
                    <div class="page-title-box">
                        <div class="page-title-right">
                            <ol class="breadcrumb m-0">
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Abstack</a></li>
                                <li class="breadcrumb-item"><a href="javascript: void(0);">Forms</a></li>
                                <li class="breadcrumb-item active">Form Validation</li>
                            </ol>
                        </div>
                        <h4 class="page-title">Form Validation</h4>
                    </div>
                </div>
            </div>
            <!-- end page title -->

            <div class="row">
                <div class="col-lg-6">

                    <div class="card-box">
                        <h4 class="header-title">Experience</h4>
                        <p class="sub-header">
                            Create The Experience In Your From
                        </p>
                        <form class="parsley-examples" action="photo-edit-post.php" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <input type="hidden" name="upload_id" value="<?= $_GET['id']  ?>">
                                <label for="userName">Name<span class="text-danger">*</span></label>
                                <input type="text" name="name" value="<?= testone_single_data('uploadphotos', $_GET['id'])['name']  ?>" placeholder="Enter user name" class="form-control">
                            </div>
                            <div class="form-group">
                                <input type="hidden" name="old_photo_name" value="<?= testone_single_data('uploadphotos', $_GET['id'])['new_photo_name']  ?>">
                                <label for="emailAddress">Old Photo Name<span class="text-danger">*</span></label>
                                <input name="new_photo_name" type="file" parsley-trigger="change" class="form-control" onchange="readURL(this);">
                                <img class="hidden" id="new_photo_name_viewer" src="#" alt="your image" />
                                <script>
                                    function readURL(input) {
                                        if (input.files && input.files[0]) {
                                            var reader = new FileReader();
                                            reader.onload = function(e) {
                                                $('#new_photo_name_viewer').attr('src', e.target.result).width(150).height(195);
                                            };
                                            $('#new_photo_name_viewer').removeClass('hidden');
                                            reader.readAsDataURL(input.files[0]);
                                        }
                                    }
                                </script>
                            </div>
                            <div class=" form-group">
                                <label for="pass1">Description<span class="text-danger">*</span></label>
                                <textarea name="description" class="form-control"><?= testone_single_data('uploadphotos', $_GET['id'])['description']  ?></textarea>
                            </div>

                            <div class="form-group text-right mb-0">
                                <button class="btn btn-gradient waves-effect waves-light" type="submit">
                                    Update
                                </button>
                                <button type="reset" class="btn btn-light waves-effect ml-1">
                                    Cancel
                                </button>
                            </div>

                        </form>
                    </div> <!-- end card-box -->
                </div>
                <!-- end col -->

                <div class="col-lg-6">
                    <div class="card-box">
                        <h4 class="header-title">Table</h4>
                        <p class="sub-header">
                            Parsley is a javascript form validation library. It helps you provide your users with feedback on their form submission before sending it to your server.
                        </p>
                        <table class="table mb-0">
                            <thead>
                                <tr>
                                    <th>Name</th>
                                    <th>Duration</th>
                                    <th>description</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach (testone('uploadphotos') as $photo) :
                                ?>
                                    <tr>
                                        <th><?= $photo['name']  ?></th>
                                        <th>
                                            <img src="../images/uploadphotos/<?= testone_single_data('uploadphotos', $_GET['id'])['new_photo_name']  ?>" alt="not found" width="100px">
                                        </th>
                                        <th><?= $photo['description']  ?></th>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>

                </div> <!-- end col -->
            </div>
            <!-- end row -->


        </div> <!-- end container-fluid -->

    </div> <!-- end content -->


    <?php
    require_once "inc/footer.php";
    ?>