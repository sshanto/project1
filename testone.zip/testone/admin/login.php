<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Abstack - Responsive Bootstrap 4 Admin Dashboard</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="images/favicon.ico">

    <!-- App css -->
    <link href="css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="css/app.min.css" rel="stylesheet" type="text/css" />

</head>

<body class="authentication-bg bg-gradient">
    <div class="account-pages mt-5 pt-5 mb-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-8 col-lg-6 col-xl-5">
                    <div class="card bg-pattern">

                        <div class="card-body p-4">

                            <div class="text-center w-75 m-auto">
                                <a href="index.html">
                                    <span><img src="images/logo-dark.png" alt="" height="18"></span>
                                </a>
                                <h5 class="text-uppercase text-center font-bold mt-4">Sign In</h5>

                            </div>
                            <?php if (isset($_SESSION['success'])) : ?>
                                <div class="alert alert-success">
                                    <?= $_SESSION['success'] ?>
                                </div>
                            <?php endif; ?>
                            <?php if (isset($_SESSION['login_error'])) : ?>
                                <div class="alert alert-danger">
                                    <?= $_SESSION['login_error'] ?>
                                </div>
                            <?php endif; ?>
                            <form action="login_post.php" method="POST">
                                <div class="form-group mb-3">
                                    <label for="emailaddress">Email address</label>
                                    <input name="email" class="form-control" type="email" id="emailaddress"  placeholder="Enter your email" value="<?=(isset($_SESSION['email_value'])) ? $_SESSION['email_value'] : '' ?>">
                                </div>

                                <div class="form-group mb-3">
                                    <a href="pages-recoverpw.html" class="text-muted float-right"><small>Forgot your password?</small></a>

                                    <label for="password">Password</label>
                                    <input name="password" class="form-control" type="password"  id="password" placeholder="Enter your password">
                                </div>

                                <div class="form-group mb-0 text-center">
                                    <button class="btn btn-gradient btn-block" type="submit"> Log In </button>
                                </div>

                            </form>

                            <div class="row mt-4">
                                <div class="col-sm-12 text-center">
                                    <p class="text-muted mb-0">Don't have an account? <a href="register.php" class="text-dark ml-1"><b>Sign Up</b></a></p>
                                </div>
                            </div>


                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->



                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->


    <!-- Vendor js -->
    <script src="js/vendor.min.js"></script>

    <!-- App js -->
    <script src="js/app.min.js"></script>
    <!-- se -->
    <?php if (isset($_SESSION['success'])) : ?>
        <div class="jq-toast-wrap top-right">
            <div class="jq-toast-single jq-has-icon jq-icon-success" style="text-align: left; display: none;"><span class="jq-toast-loader jq-toast-loaded" style="-webkit-transition: width 2.6s ease-in;                       -o-transition: width 2.6s ease-in;                       transition: width 2.6s ease-in;                       background-color: #5ba035;"></span><span class="close-jq-toast-single">×</span>
                <h2 class="jq-toast-heading">Well done!</h2><?= $_SESSION['success'] ?>
            </div>
        </div>
    <?php endif; ?>

</body>

</html>

<?php
session_unset();
?>