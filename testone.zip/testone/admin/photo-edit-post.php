<?php
require_once "../db.php";
if ($_FILES['new_photo_name']['name']) {
    $link = $_SERVER['DOCUMENT_ROOT'] . "/testone/images/uploadphotos/"  . $_POST['old_photo_name'];
    unlink($link);


    // photo uploads start
    $uploads_photo = $_FILES['new_photo_name'];
    $after_explode = explode('.', $uploads_photo['name']);
    $new_photo_name = rand() . time() . "." . end($after_explode);
    $uploads_temp_location = $uploads_photo['tmp_name'];
    $new_location = '../images/uploadphotos/' . $new_photo_name;
    move_uploaded_file($uploads_temp_location, $new_location);
    // photo uploads end

    // update with database
    $post_name_photo = $_POST['old_photo_name'];
    $update_query = "UPDATE uploadphotos SET new_photo_name = '$new_photo_name',  WHERE new_photo_name =  '$post_name_photo'";
    mysqli_query(connect_to_db(), $update_query);
}

    $upload_id = $_POST['upload_id'];
    $name = $_POST['name'];
    $description = $_POST['description'];
    
    $update_query = "UPDATE uploadphotos SET  name = '$name', description = '$description' WHERE id =  $upload_id";
    mysqli_query(connect_to_db(), $update_query);

header("location: photo-uploads.php");
?>