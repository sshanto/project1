<?php
require_once "../db.php";
    $name = $_POST['name'];
    $duration = $_POST['duration'];
    $description = htmlspecialchars($_POST['description'], ENT_QUOTES);
    date_default_timezone_set('Asia/Dhaka');
    $date_time = date('Y-m-d H:i:s');

// $insert_query = "INSERT INTO experiences (name, duration, description, created_at) VALUES ('$name','$duration','$description','$date_time')";
// $register_query = mysqli_query(connect_to_db(), $insert_query);
// header("location: experience.php");


$returen_v = testone_insert("experiences", "name, duration, description, created_at", "'$name','$duration','$description','$date_time'");
// print_r($returen_v);
if ($returen_v) {
    header("location: experience.php");
}
?>