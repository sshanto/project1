<?php 
session_start();
require_once "../db.php";
$email = $_POST['email'];
$password = md5($_POST['password']);
$count_query = "SELECT COUNT(*) AS login_capablity FROM users WHERE email='$email' AND password='$password'";
$backup_database = mysqli_query(connect_to_db(), $count_query);
$data_assoc = mysqli_fetch_assoc($backup_database);
if ($data_assoc['login_capablity'] == 1) {
    $_SESSION['login_status'] = true;
    $_SESSION['login_email'] = $email;
    $name_query = "SELECT name FROM users WHERE email='$email'";
    $_SESSION['login_name'] = mysqli_fetch_assoc(mysqli_query(connect_to_db(), $name_query))['name'];
    header('location: dashbord.php');
}
else{
    $_SESSION['login_error'] = "Email Password Is Incoruct";
    header('location: login.php');
}
?>