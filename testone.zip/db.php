<?php
function connect_to_db(){
    $hostname = "localhost";
    $username = "root";
    $password = "";
    $database_name = "testone";
    return $db_connact = mysqli_connect($hostname, $username, $password, $database_name);
}

// সব গুলো টেবিল কে  এক সাথে দরা।
function testone($table_name){
    $select_query = "SELECT * FROM $table_name";
    return $db_query = mysqli_query(connect_to_db(), $select_query);
}
// একটা টেবিল কে  এক সাথে দরা।
function testone_single_data($table_name, $id){
    $single_select_query = "SELECT * FROM $table_name WHERE id = $id";
    return $db_query = mysqli_fetch_assoc(mysqli_query(connect_to_db(), $single_select_query));
}

//  যে কইটা লাগে ওই কইটা কে দরা।
function testone_only_select_number_of($table_name, $how_many){
    $select_query = "SELECT * FROM $table_name ORDER BY id DESC LIMIT $how_many";
    return $db_query = mysqli_query(connect_to_db(), $select_query);
}
// ডাটা  ইনর্সাট করা
function testone_insert($table_name, $fild_name, $fild_value){
    $insert_query = "INSERT INTO $table_name ($fild_name) VALUES ($fild_value)";
    return mysqli_query(connect_to_db(), $insert_query);
}

//  ডাটা ডিলিট করা।
function testone_delete($table_name, $fild_name, $fild_value){
    $delete_query = "DELETE FROM $table_name WHERE $fild_name = $fild_value";
    return mysqli_query(connect_to_db(), $delete_query);
}

// ফটো ডিলিট করার জন্য
function testone_delete_photo($table_name, $fild_name, $fild_value, $photo_fild_name){
    $select_query = "SELECT * FROM $table_name WHERE $fild_name = $fild_value";
    $db_query = mysqli_query(connect_to_db(), $select_query);
    $new_photo_name = mysqli_fetch_assoc($db_query)[$photo_fild_name];
    $link = __DIR__."/images/". $table_name."/". $new_photo_name;
    unlink($link);
    $delete_query = "DELETE FROM $table_name WHERE $fild_name = $fild_value";
    return mysqli_query(connect_to_db(), $delete_query);
}

//  author name catch
function testone_setup($table_name, $setup_name){
    // echo $table_name;
    $query = "SELECT setup_value FROM $table_name WHERE setup_name = '$setup_name'";
    return mysqli_fetch_assoc(mysqli_query(connect_to_db(), $query))['setup_value'];
}



?>
